-- Run this in your Supabase SQL Editor (supabase.com → your project → SQL Editor)

-- 1. Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT,
  first_name TEXT,
  last_name TEXT,
  handicap NUMERIC(4,1),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Rounds table
CREATE TABLE IF NOT EXISTS rounds (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL,
  course TEXT,
  tees TEXT,
  weather TEXT,
  temp TEXT,
  wind TEXT,
  holes JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, first_name, last_name, handicap)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'first_name',
    NEW.raw_user_meta_data->>'last_name',
    (NEW.raw_user_meta_data->>'handicap')::NUMERIC
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- 4. Row Level Security — users can only see their own rounds
ALTER TABLE rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Rounds policies
CREATE POLICY "Users can read own rounds" ON rounds FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own rounds" ON rounds FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own rounds" ON rounds FOR DELETE USING (auth.uid() = user_id);

-- Profiles policies  
CREATE POLICY "Users can read own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- 5. Admin can read all (replace with your actual admin user ID from Supabase Auth dashboard)
-- CREATE POLICY "Admin reads all rounds" ON rounds FOR SELECT USING (auth.uid() = 'YOUR-ADMIN-USER-ID');
-- CREATE POLICY "Admin reads all profiles" ON profiles FOR SELECT USING (auth.uid() = 'YOUR-ADMIN-USER-ID');

-- Grant PostgREST access (required for projects created after May 30, 2026)
GRANT SELECT, INSERT, DELETE ON rounds TO authenticated;
GRANT SELECT, UPDATE ON profiles TO authenticated;
GRANT SELECT ON profiles TO authenticated;
