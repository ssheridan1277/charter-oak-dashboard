# My Round — Golf Performance Log

## Quick Deploy (Netlify Drop)
1. Run `npm install && npm run build`
2. Drag the `dist/` folder to netlify.com/drop
3. Done — app is live

## Setup Steps

### 1. Create Supabase project (free)
- Go to supabase.com → New Project
- Name it `my-round`
- Copy your **Project URL** and **Anon Key** from Settings → API

### 2. Configure the app
Edit `src/supabase.js`:
```js
const SUPABASE_URL = "https://xxxx.supabase.co"      // your URL
const SUPABASE_ANON_KEY = "eyJ..."                    // your anon key
export const ADMIN_EMAIL = "you@youremail.com"        // your email for admin access
```

### 3. Run the database schema
- Go to your Supabase project → SQL Editor
- Paste and run the contents of `supabase-setup.sql`

### 4. Enable Admin access to all member data
- In Supabase → Authentication → Users, find your user and copy your User ID
- Uncomment the admin policy lines at the bottom of `supabase-setup.sql` and paste your ID
- Re-run those lines

### 5. Build and deploy
```bash
npm install
npm run build
# Drag dist/ to netlify.com/drop
```

## Run locally
```bash
npm install
npm run dev
# Open http://localhost:5173
```

## Features
- 📍 GPS course auto-detection
- 🔐 Email/password accounts (max 250 users)
- ☁️ Cloud sync — rounds accessible on any device
- 👔 Admin dashboard — see all member stats
- 🤖 AI Coach (Claude-powered)
- 📊 Strokes gained, miss maps, club distances, trends
- 📄 Download + share reports
- 📱 PWA — installs to phone home screen
