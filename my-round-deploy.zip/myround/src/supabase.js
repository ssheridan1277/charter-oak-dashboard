import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = "https://ooboppdzrlhepsaareqf.supabase.co"
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9vYm9wcGR6cmxoZXBzYWFyZXFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAxNjYwMDQsImV4cCI6MjA5NTc0MjAwNH0.XAkeyn7mD3L39djKSm4N_ySD4b_ptoVZP6dn404GIC4"

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

export const ADMIN_EMAIL = "steve@charteroakcc.com"
export const MAX_USERS = 250
