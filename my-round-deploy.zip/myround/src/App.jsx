import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { supabase, ADMIN_EMAIL } from "./supabase";
import Auth from "./Auth";
import AdminDashboard from "./Admin";

const CLUBS = ["Driver","3W","5W","2H","3H","4H","5H","3i","4i","5i","6i","7i","8i","9i","PW","GW","SW","LW","Putter"];

const C = {
  bg:"#0d1a12", card:"#132019", card2:"#0f1c15",
  border:"#1e3328", accent:"#c8a84b", accentDim:"#8a6e28",
  green:"#3dba6c", red:"#e05252", text:"#e8ead4", muted:"#7a8c7f",
  hit:"#1e4230", miss:"#3d1414",
};

const emptyHole = () => ({
  par:4, score:"", fir:null, gir:null, putts:"", upDown:null,
  approachDist:"", approachClub:"", driveClub:"Driver",
  approachMiss:null, driveMiss:null,
  penalties:0, sandSave:null, inSand:false, notes:"",
});

const newRound = (holeCount=18) => ({
  id: Date.now(),
  date: new Date().toISOString().slice(0,10),
  course:"", tees:"", weather:"", holeCount,
  holes: Array.from({length:holeCount}, emptyHole),
  saved:false, setup:true,
});

function pct(n,d) { if(!d) return "—"; return Math.round(n/d*100)+"%"; }
function toPar(n) { if(n===null||n===undefined) return "—"; if(n===0) return "E"; return n>0?`+${n}`:`${n}`; }
function toParCls(n) { if(!n&&n!==0) return "ep"; return n>0?"rp":n<0?"gp":"ep"; }

function scoreInfo(score, par) {
  if(!score||score==="") return {label:"",cls:""};
  const d = Number(score)-par;
  if(d<=-2) return {label:"Eagle",cls:"s-eagle"};
  if(d===-1) return {label:"Birdie",cls:"s-birdie"};
  if(d===0)  return {label:"Par",cls:"s-par"};
  if(d===1)  return {label:"Bogey",cls:"s-bogey"};
  if(d===2)  return {label:"Dbl",cls:"s-double"};
  return {label:"+++",cls:"s-worse"};
}

function calcStats(holes) {
  const played = holes.filter(h=>h.score!=="");
  const np3 = played.filter(h=>h.par!==3);
  const firHit = np3.filter(h=>h.fir===true).length;
  const girHit = played.filter(h=>h.gir===true).length;
  const puttsArr = played.map(h=>Number(h.putts)).filter(v=>v>0);
  const totalPutts = puttsArr.reduce((a,b)=>a+b,0);
  const udH = played.filter(h=>h.gir===false&&h.upDown!==null);
  const udMade = udH.filter(h=>h.upDown===true).length;
  const sandH = played.filter(h=>h.inSand&&h.sandSave!==null);
  const sandMade = sandH.filter(h=>h.sandSave===true).length;
  const totalScore = played.reduce((a,h)=>a+(Number(h.score)||0),0);
  const totalPar = played.reduce((a,h)=>a+h.par,0);
  const bench = {3:3.0,4:3.99,5:4.74};
  let sg=0; played.forEach(h=>{if(h.score!=="")sg+=bench[h.par]-Number(h.score);});
  const ads = played.map(h=>Number(h.approachDist)).filter(v=>v>0);
  return {
    played:played.length, totalScore, totalPar, toPar:totalScore-totalPar,
    firHit, firTotal:np3.length, girHit, girTotal:played.length,
    totalPutts, avgPutts:puttsArr.length?(totalPutts/puttsArr.length).toFixed(1):null,
    udMade, udTotal:udH.length, sandMade, sandTotal:sandH.length,
    avgApproach:ads.length?Math.round(ads.reduce((a,b)=>a+b,0)/ads.length):null,
    sg:sg.toFixed(1), penalties:played.reduce((a,h)=>a+(h.penalties||0),0),
  };
}

function buildClubDistances(rounds) {
  const map={};
  rounds.forEach(r=>r.holes.forEach(h=>{
    if(h.approachClub&&h.approachDist){
      if(!map[h.approachClub])map[h.approachClub]=[];
      map[h.approachClub].push(Number(h.approachDist));
    }
  }));
  return Object.entries(map).map(([club,dists])=>({
    club, avg:Math.round(dists.reduce((a,b)=>a+b,0)/dists.length), count:dists.length,
  })).sort((a,b)=>b.avg-a.avg);
}

function buildMissMap(rounds) {
  const drive={Left:0,Right:0,Short:0,Long:0,Center:0};
  const approach={Left:0,Right:0,Short:0,Long:0,Center:0};
  rounds.forEach(r=>r.holes.forEach(h=>{
    if(h.driveMiss) drive[h.driveMiss]=(drive[h.driveMiss]||0)+1;
    if(h.approachMiss) approach[h.approachMiss]=(approach[h.approachMiss]||0)+1;
  }));
  return {drive,approach};
}

async function getAICoach(stats) {
  const resp = await fetch("https://api.anthropic.com/v1/messages",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({
      model:"claude-sonnet-4-20250514", max_tokens:1000,
      system:`You are an expert PGA golf coach. Analyze stats and give 3 specific improvement tips.
      Return ONLY valid JSON: {"tips":[{"area":"...","insight":"...","drill":"...","priority":"high|medium|low"}]}`,
      messages:[{role:"user",content:`Stats: FIR ${stats.firPct}, GIR ${stats.girPct}, Putts/round ${stats.avgPutts}, U&D ${stats.udPct}, Avg score ${stats.avgScore}, Sand ${stats.sandPct}`}],
    }),
  });
  const data = await resp.json();
  const text = data.content?.map(b=>b.text||"").join("");
  return JSON.parse(text.replace(/```json|```/g,"").trim());
}

function generateRoundHTML(round,s) {
  const tp = s.toPar===0?"E":s.toPar>0?`+${s.toPar}`:`${s.toPar}`;
  const rows = round.holes.map((h,i)=>{
    if(h.score==="") return "";
    const d=Number(h.score)-h.par;
    const label=d<=-2?"Eagle":d===-1?"Birdie":d===0?"Par":d===1?"Bogey":d===2?"Double":"Triple+";
    const color=d<0?"#3dba6c":d===0?"#c8a84b":"#e05252";
    return `<tr><td>${i+1}</td><td>${h.par}</td><td style="font-weight:900;color:${color}">${h.score}</td><td style="color:${color};font-size:11px">${label}</td><td>${h.putts||"—"}</td><td>${h.fir===true?"✓":h.fir===false?"✕":"—"}</td><td>${h.gir===true?"✓":h.gir===false?"✕":"—"}</td><td>${h.inSand?h.sandSave===true?"✓":"✕":"—"}</td><td>${h.approachDist?h.approachDist+"y":"—"}</td><td>${h.approachClub||"—"}</td></tr>`;
  }).join("");
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${round.course} — My Round</title>
<style>body{font-family:'Arial Black',sans-serif;background:#f9f7f2;color:#1a1a1a;margin:0;padding:0}.page{max-width:820px;margin:0 auto;padding:40px 32px}.header{border-bottom:3px solid #c8a84b;padding-bottom:20px;margin-bottom:28px;display:flex;justify-content:space-between;align-items:flex-end}.title{font-size:28px;font-weight:900}.subtitle{font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#888;margin-top:4px;font-weight:700}.score-hero{text-align:right}.score-big{font-size:52px;font-weight:900;line-height:1;color:${s.toPar>0?"#e05252":s.toPar<0?"#3dba6c":"#888"}}.stat-row{display:flex;gap:0;margin-bottom:28px;border:1px solid #e0dcd0;border-radius:8px;overflow:hidden}.stat-box{flex:1;padding:14px 16px;border-right:1px solid #e0dcd0;text-align:center}.stat-box:last-child{border-right:none}.stat-val{font-size:22px;font-weight:900;color:#c8a84b}.stat-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#888;font-weight:700}table{width:100%;border-collapse:collapse;font-size:13px}th{background:#1a2a1a;color:#c8a84b;padding:9px 10px;text-align:left;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;font-weight:900}td{padding:8px 10px;border-bottom:1px solid #e8e4da}tr:nth-child(even){background:#f3f0e8}.footer{margin-top:32px;font-size:11px;color:#aaa;text-align:center;border-top:1px solid #e0dcd0;padding-top:16px;font-weight:700}</style>
</head><body><div class="page">
<div class="header"><div><div class="title">${round.course||"Round Report"}</div><div class="subtitle">${round.date}${round.tees?" · "+round.tees:""}${round.holeCount?" · "+round.holeCount+" holes":""}</div></div>
<div class="score-hero"><div class="score-big">${tp}</div><div class="stat-lbl">${s.totalScore} strokes · ${s.played} holes</div></div></div>
<div class="stat-row">
<div class="stat-box"><div class="stat-val">${pct(s.firHit,s.firTotal)}</div><div class="stat-lbl">FIR</div></div>
<div class="stat-box"><div class="stat-val">${pct(s.girHit,s.girTotal)}</div><div class="stat-lbl">GIR</div></div>
<div class="stat-box"><div class="stat-val">${s.totalPutts||"—"}</div><div class="stat-lbl">Putts</div></div>
<div class="stat-box"><div class="stat-val">${pct(s.udMade,s.udTotal)}</div><div class="stat-lbl">U&amp;D</div></div>
<div class="stat-box"><div class="stat-val">${pct(s.sandMade,s.sandTotal)}</div><div class="stat-lbl">Sand</div></div>
<div class="stat-box"><div class="stat-val">${s.sg}</div><div class="stat-lbl">SG</div></div>
</div>
<table><thead><tr><th>#</th><th>Par</th><th>Score</th><th>Result</th><th>Putts</th><th>FIR</th><th>GIR</th><th>Sand</th><th>Dist</th><th>Club</th></tr></thead><tbody>${rows}</tbody></table>
<div class="footer">My Round · ${new Date().toLocaleDateString()}</div>
</div></body></html>`;
}

function downloadReport(html,filename) {
  const blob = new Blob([html],{type:"text/html"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href=url; a.download=filename; a.click();
  URL.revokeObjectURL(url);
}

async function shareReport(html,title) {
  const blob = new Blob([html],{type:"text/html"});
  const file = new File([blob],`${title}.html`,{type:"text/html"});
  if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
    await navigator.share({title,files:[file]});
  } else {
    downloadReport(html,`${title}.html`);
  }
}

const css = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@400;700;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:${C.bg}}
.app{font-family:'DM Sans','Arial Black',sans-serif;color:${C.text};min-height:100vh;background:${C.bg};max-width:900px;margin:0 auto;padding-bottom:80px}
.header{padding:20px 20px 14px;border-bottom:1px solid ${C.border};display:flex;align-items:flex-end;justify-content:space-between;gap:12px}
.logo{font-family:'Playfair Display',Georgia,serif;font-size:24px;font-weight:900;letter-spacing:-0.5px}
.logo span{color:${C.accent}}
.logo-sub{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:${C.muted};margin-top:3px;font-weight:900}
.nav{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;padding:11px 16px;background:${C.card};border-bottom:1px solid ${C.border};position:sticky;top:0;z-index:20}
.nb{padding:9px 5px;font-size:10px;font-weight:900;letter-spacing:.8px;text-transform:uppercase;color:${C.muted};background:${C.bg};border:1px solid ${C.border};border-radius:8px;cursor:pointer;text-align:center;transition:all .15s;font-family:inherit}
.nb.active{background:${C.accent};color:#0d1a12;border-color:${C.accent}}
.nb:hover:not(.active){color:${C.text};border-color:${C.muted}}
.sec{padding:18px 20px}
.inp{background:${C.card};border:1px solid ${C.border};border-radius:6px;color:${C.text};font-family:inherit;font-size:13px;font-weight:700;padding:8px 11px;outline:none;transition:border-color .2s}
.inp:focus{border-color:${C.accent}}
select.inp{cursor:pointer}
.card{background:${C.card};border:1px solid ${C.border};border-radius:10px;padding:13px 15px;margin-bottom:10px}
.lbl{font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:${C.muted};margin-bottom:4px;display:block;font-weight:900}
.field{display:flex;flex-direction:column}
.row{display:flex;gap:9px;flex-wrap:wrap;align-items:flex-end}
.btn{background:${C.accent};color:#0d1a12;border:none;border-radius:8px;padding:10px 18px;font-family:inherit;font-size:13px;font-weight:900;cursor:pointer;transition:opacity .2s;letter-spacing:.3px}
.btn:hover{opacity:.85}
.btn:disabled{opacity:.4;cursor:not-allowed}
.btn-ghost{background:none;color:${C.muted};border:1px solid ${C.border};border-radius:8px;padding:8px 14px;font-family:inherit;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s}
.btn-ghost:hover{color:${C.text};border-color:${C.muted}}
.btn-sm{padding:6px 12px;font-size:11px}
.divider{border:none;border-top:1px solid ${C.border};margin:12px 0}
.section-title{font-family:'Playfair Display',Georgia,serif;font-size:16px;font-weight:900;margin-bottom:12px}

/* ── Hole count selector ── */
.hole-sel{display:flex;gap:10px;margin-bottom:18px}
.hole-sel-btn{flex:1;padding:16px;font-size:20px;font-weight:900;border-radius:10px;border:2px solid ${C.border};cursor:pointer;background:#0d1a12;color:${C.muted};font-family:inherit;transition:all .15s;text-align:center;line-height:1}
.hole-sel-btn span{display:block;font-size:10px;font-weight:900;letter-spacing:1.5px;text-transform:uppercase;margin-top:4px;opacity:.7}
.hole-sel-btn.active{background:${C.accent};color:#0d1a12;border-color:${C.accent}}

/* ── Score picker ── */
.score-picker{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px}
.score-btn{width:42px;height:44px;border-radius:8px;border:1px solid ${C.border};background:#0d1a12;color:${C.muted};font-size:16px;font-weight:900;cursor:pointer;font-family:inherit;transition:all .15s;display:flex;align-items:center;justify-content:center;flex-direction:column;line-height:1}
.score-btn .slbl{font-size:7px;letter-spacing:.3px;font-weight:900;text-transform:uppercase;margin-top:2px}
.score-btn:hover{border-color:${C.muted};color:${C.text}}
.score-btn.s-eagle{background:#2a2000;border-color:#ffd700;color:#ffd700}
.score-btn.s-birdie{background:${C.hit};border-color:${C.green};color:#a8ffc4}
.score-btn.s-par{background:#1a2a3a;border-color:#6b8fe0;color:#a0b4ff}
.score-btn.s-bogey{background:#2a1e00;border-color:#e8a84b;color:#e8a84b}
.score-btn.s-double{background:${C.miss};border-color:${C.red};color:#ffa8a8}
.score-btn.s-worse{background:#4a0808;border-color:#ff4444;color:#ff9999}

/* ── Putts picker ── */
.putts-picker{display:flex;gap:5px;margin-bottom:14px}
.putt-btn{width:40px;height:40px;border-radius:8px;border:1px solid ${C.border};background:#0d1a12;color:${C.muted};font-size:16px;font-weight:900;cursor:pointer;font-family:inherit;transition:all .15s;display:flex;align-items:center;justify-content:center}
.putt-btn:hover{border-color:${C.muted};color:${C.text}}
.putt-btn.sel{background:#1a2a3a;border-color:#6b8fe0;color:#a0b4ff}

/* ── Toggle buttons ── */
.tog-section{margin-bottom:12px}
.tog-group{display:flex;gap:5px;flex-wrap:wrap}
.tog{padding:9px 14px;font-size:11px;font-weight:900;border-radius:8px;border:1px solid ${C.border};cursor:pointer;background:#0d1a12;color:${C.muted};transition:all .15s;font-family:inherit;letter-spacing:.5px;text-transform:uppercase}
.tog:hover{border-color:${C.muted};color:${C.text}}
.tog.hit{background:${C.hit};border-color:${C.green};color:#a8ffc4}
.tog.miss{background:${C.miss};border-color:${C.red};color:#ffa8a8}
.tog.warn{background:#2a1800;border-color:#e8a84b;color:#e8a84b}

/* ── Miss direction grid ── */
.miss-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;max-width:210px}
.miss-btn{padding:8px 4px;font-size:10px;font-weight:900;border-radius:7px;border:1px solid ${C.border};cursor:pointer;background:#0d1a12;color:${C.muted};font-family:inherit;text-align:center;transition:all .15s;letter-spacing:.5px}
.miss-btn:hover{border-color:${C.muted};color:${C.text}}
.miss-btn.sel{background:#2a2010;border-color:${C.accent};color:${C.accent}}
.miss-spacer{width:100%;height:100%}

/* ── Dots ── */
.dots{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:13px}
.dot{width:27px;height:27px;border-radius:50%;border:1px solid ${C.border};background:${C.card};color:${C.muted};font-size:9px;font-weight:900;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}
.dot.done{background:${C.hit};color:#a8ffc4;border-color:${C.green}}
.dot.active{background:${C.accent};color:#0d1a12;border-color:${C.accent}}
.nav-hole{display:flex;justify-content:space-between;align-items:center;margin-top:14px;gap:10px}
.nav-hole .btn{flex:1}

/* ── Stats ── */
.stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:18px}
.stat-tile{background:${C.card};border:1px solid ${C.border};border-radius:10px;padding:12px 14px}
.stat-val{font-size:24px;font-weight:900;color:${C.accent};line-height:1;margin-bottom:3px}
.stat-lbl{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:${C.muted};font-weight:900}
.stat-sub{font-size:11px;color:${C.muted};margin-top:2px;font-weight:700}
.bar-wrap{background:${C.border};border-radius:4px;height:5px;margin-top:5px;overflow:hidden}
.bar-fill{height:100%;border-radius:4px;background:${C.accent};transition:width .6s ease}
.chip{display:inline-block;padding:2px 8px;border-radius:20px;font-size:9px;font-weight:900;letter-spacing:.6px;text-transform:uppercase}
.chip-g{background:${C.hit};color:#a8ffc4}
.chip-a{background:#2a2010;color:${C.accent}}
.chip-b{background:#1a2035;color:#a0b4ff}
.round-item{background:${C.card};border:1px solid ${C.border};border-radius:10px;padding:13px 15px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px;cursor:pointer;transition:border-color .2s,background .2s}
.round-item:hover{border-color:${C.accent};background:#172820}
.gp{color:${C.green}}.rp{color:${C.red}}.ep{color:${C.muted}}.ap{color:${C.accent}}
.coach-tip{background:#0f2018;border:1px solid ${C.accentDim};border-radius:10px;padding:13px 15px;margin-bottom:10px}
.tip-area{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:${C.accent};margin-bottom:4px;font-weight:900}
.tip-drill{font-size:12px;font-weight:700;color:#a8d4b8;background:rgba(61,186,108,.1);border-left:2px solid ${C.green};padding:6px 10px;border-radius:0 4px 4px 0;margin-top:6px}
.trend-card{background:${C.card};border:1px solid ${C.border};border-radius:10px;padding:12px 14px;margin-bottom:10px}
.trend-title{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:${C.muted};margin-bottom:10px;font-weight:900}
.club-row{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid ${C.border}}
.club-row:last-child{border-bottom:none}
.club-name{font-size:12px;font-weight:900;width:58px;flex-shrink:0}
.club-dist{font-size:18px;font-weight:900;color:${C.accent};width:54px}
.miss-cell{background:${C.card2};border:1px solid ${C.border};border-radius:6px;padding:8px;text-align:center}
.miss-cell.hot{border-color:${C.red};background:${C.miss}}
.miss-cell-val{font-size:18px;font-weight:900;color:${C.accent}}
.miss-cell-lbl{font-size:8px;letter-spacing:1px;text-transform:uppercase;color:${C.muted};font-weight:900}
.miss-cell.hot .miss-cell-val{color:#ffa8a8}
.empty-state{text-align:center;padding:50px 20px;color:${C.muted}}
.empty-state h3{font-family:'Playfair Display',Georgia,serif;font-size:20px;color:${C.text};margin-bottom:6px;font-weight:900}
.setup-card{background:${C.card};border:1px solid ${C.border};border-radius:14px;padding:24px 20px;max-width:480px;margin:20px auto}
.setup-title{font-family:'Playfair Display',Georgia,serif;font-size:22px;font-weight:900;margin-bottom:4px}
.setup-sub{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:${C.muted};font-weight:900;margin-bottom:20px}
@media(max-width:600px){.stat-grid{grid-template-columns:repeat(2,1fr)}}
`;

const TABS = [["scorecard","Scorecard"],["rounds","Rounds"],["stats","Stats"],["clubs","Clubs"],["misses","Misses"],["trends","Trends"],["coach","AI Coach"],["report","Report"]];

export default function GolfTracker() {
  const [tab, setTab] = useState("scorecard");
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [rounds, setRounds] = useState([]);
  const [current, setCurrent] = useState(() => newRound(18));
  const [currentHole, setCurrentHole] = useState(0);
  const [viewRound, setViewRound] = useState(null);
  const [gpsStatus, setGpsStatus] = useState("idle");
  const [detectedCourse, setDetectedCourse] = useState(null);
  const [courseOptions, setCourseOptions] = useState([]);
  const [coachData, setCoachData] = useState(null);
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachError, setCoachError] = useState(null);
  const apiKey = "TCKFFHLPFFLU3M3ZXPT4337ZCE";

  useEffect(() => {
    supabase.auth.getSession().then(({data:{session}}) => {
      setUser(session?.user ?? null);
      setAuthLoading(false);
    });
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_,session) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if(!user) { setRounds([]); return; }
    loadRounds();
  }, [user]);

  const loadRounds = async () => {
    const {data,error} = await supabase.from("rounds").select("*").eq("user_id",user.id).order("date",{ascending:false});
    if(!error&&data) setRounds(data.map(r=>({...r,holes:r.holes||[]})));
  };

  const setHole = (idx, field, val) => {
    setCurrent(r => ({...r, holes:r.holes.map((h,i)=>i!==idx?h:{...h,[field]:val})}));
  };
  const toggleHole = (idx, field, val) => {
    const cur = current.holes[idx][field];
    setHole(idx, field, cur===val?null:val);
  };

  const saveRound = async () => {
    const roundToSave = {
      user_id:user.id, date:current.date, course:current.course, tees:current.tees,
      weather:current.weather, holeCount:current.holeCount, holes:current.holes,
    };
    const {data,error} = await supabase.from("rounds").insert([roundToSave]).select();
    if(!error&&data) {
      setRounds(prev=>[{...data[0],holes:data[0].holes||[]},...prev]);
      setCurrent(newRound(18)); setCurrentHole(0); setTab("rounds");
    } else alert("Error saving: "+error?.message);
  };

  const deleteRoundById = async (id) => {
    await supabase.from("rounds").delete().eq("id",id);
    setRounds(prev=>prev.filter(r=>r.id!==id));
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setUser(null); setRounds([]);
  };

  const detectCourse = async () => {
    setGpsStatus("locating"); setDetectedCourse(null); setCourseOptions([]);
    try {
      const pos = await new Promise((res,rej) => navigator.geolocation.getCurrentPosition(res,rej,{timeout:10000}));
      const {latitude,longitude} = pos.coords;
      setGpsStatus("searching");
      const resp = await fetch(`https://api.golfcourseapi.com/v1/search?latitude=${latitude}&longitude=${longitude}&distance_miles=2`,{headers:{Authorization:`Key ${apiKey}`}});
      if(!resp.ok) throw new Error("API error");
      const data = await resp.json();
      const courses = data.courses||[];
      if(courses.length===0){setGpsStatus("error");return;}
      if(courses.length===1){applyDetectedCourse(courses[0]);}
      else{setCourseOptions(courses.slice(0,5));setGpsStatus("found");}
    } catch(e){setGpsStatus("error");}
  };

  const applyDetectedCourse = async (course) => {
    setGpsStatus("found"); setDetectedCourse(course);
    try {
      const resp = await fetch(`https://api.golfcourseapi.com/v1/courses/${course.id}`,{headers:{Authorization:`Key ${apiKey}`}});
      if(!resp.ok) throw new Error();
      const data = await resp.json();
      const tees = data.tees?.male||data.tees?.female||[];
      const firstTee = tees[0];
      const holeData = firstTee?.holes||[];
      setCurrent(r=>({...r,
        course:course.club_name||course.course_name||"",
        tees:firstTee?.tee_name||"",
        holes:r.holes.map((h,i)=>({...h,par:holeData[i]?.par||h.par})),
        setup:false,
      }));
      setCourseOptions([]);
    } catch(e){
      setCurrent(r=>({...r,course:course.club_name||course.course_name||"",setup:false}));
      setCourseOptions([]);
    }
  };

  const fetchCoach = async () => {
    setCoachLoading(true); setCoachError(null);
    try {
      const allS = rounds.map(r=>calcStats(r.holes));
      const firH=allS.reduce((a,s)=>a+s.firHit,0),firT=allS.reduce((a,s)=>a+s.firTotal,0);
      const girH=allS.reduce((a,s)=>a+s.girHit,0),girT=allS.reduce((a,s)=>a+s.girTotal,0);
      const udH=allS.reduce((a,s)=>a+s.udMade,0),udT=allS.reduce((a,s)=>a+s.udTotal,0);
      const sH=allS.reduce((a,s)=>a+s.sandMade,0),sT=allS.reduce((a,s)=>a+s.sandTotal,0);
      const full=allS.filter(s=>s.played>=9);
      const avgScore=full.length?(full.reduce((a,s)=>a+s.toPar,0)/full.length).toFixed(1):null;
      const avgPutts=full.length?(full.reduce((a,s)=>a+s.totalPutts,0)/full.length).toFixed(1):null;
      const result = await getAICoach({firPct:pct(firH,firT),girPct:pct(girH,girT),udPct:pct(udH,udT),sandPct:pct(sH,sT),avgScore,avgPutts});
      setCoachData(result);
    } catch(e){setCoachError("Couldn't load tips. Check your connection.");}
    setCoachLoading(false);
  };

  // Aggregated stats
  const allStats = rounds.map(r=>calcStats(r.holes));
  const aggFirH=allStats.reduce((a,s)=>a+s.firHit,0),aggFirT=allStats.reduce((a,s)=>a+s.firTotal,0);
  const aggGirH=allStats.reduce((a,s)=>a+s.girHit,0),aggGirT=allStats.reduce((a,s)=>a+s.girTotal,0);
  const aggUdH=allStats.reduce((a,s)=>a+s.udMade,0),aggUdT=allStats.reduce((a,s)=>a+s.udTotal,0);
  const aggSandH=allStats.reduce((a,s)=>a+s.sandMade,0),aggSandT=allStats.reduce((a,s)=>a+s.sandTotal,0);
  const fullRounds=allStats.filter(s=>s.played>=9);
  const avgScore=fullRounds.length?(fullRounds.reduce((a,s)=>a+s.toPar,0)/fullRounds.length).toFixed(1):null;
  const avgPuttsR=fullRounds.length?(fullRounds.reduce((a,s)=>a+s.totalPutts,0)/fullRounds.length).toFixed(1):null;
  const allApproach=rounds.flatMap(r=>r.holes.map(h=>Number(h.approachDist)).filter(v=>v>0));
  const avgApproachAll=allApproach.length?Math.round(allApproach.reduce((a,b)=>a+b,0)/allApproach.length):null;
  const sgAvg=fullRounds.length?(fullRounds.reduce((a,s)=>a+Number(s.sg),0)/fullRounds.length).toFixed(1):null;
  const clubDists=buildClubDistances(rounds);
  const missMap=buildMissMap(rounds);
  const trendData=[...rounds].reverse().slice(-10).map(r=>{
    const s=calcStats(r.holes);
    return{name:r.date.slice(5),score:s.toPar,putts:s.totalPutts,fir:s.firTotal?Math.round(s.firHit/s.firTotal*100):0,gir:s.girTotal?Math.round(s.girHit/s.girTotal*100):0};
  });

  // Auth loading
  if(authLoading) return (
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,color:C.accent,fontWeight:900}}>My Round</div>
    </div>
  );
  if(!user) return <Auth onAuth={setUser}/>;
  if(user.email===ADMIN_EMAIL) return <AdminDashboard adminUser={user} onSignOut={handleSignOut}/>;

  return (
    <>
      <style>{css}</style>
      <div className="app">
        <div className="header">
          <div>
            <div className="logo">My<span> Round</span></div>
            <div className="logo-sub">Golf Performance Log</div>
          </div>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            {tab==="scorecard"&&!current.setup&&<button className="btn" onClick={saveRound} disabled={!current.course}>Save Round</button>}
            <button onClick={handleSignOut} style={{background:"none",border:"none",color:C.muted,fontSize:11,cursor:"pointer",fontFamily:"inherit",fontWeight:700}}>Sign Out</button>
          </div>
        </div>

        <div className="nav">
          {TABS.map(([id,label])=>(
            <button key={id} className={`nb${tab===id?" active":""}`} onClick={()=>{setTab(id);setViewRound(null);}}>{label}</button>
          ))}
        </div>

        {tab==="scorecard" && (
          <div className="sec">
            {current.setup ? (
              // ── ROUND SETUP ──
              <div className="setup-card">
                <div className="setup-title">New Round</div>
                <div className="setup-sub">Set up your round</div>

                <label className="lbl">How many holes?</label>
                <div className="hole-sel">
                  {[9,18].map(n=>(
                    <button key={n} className={`hole-sel-btn${current.holeCount===n?" active":""}`}
                      onClick={()=>setCurrent(r=>({...r,holeCount:n,holes:Array.from({length:n},emptyHole)}))}>
                      {n}<span>{n===9?"Front / Back":"Full Round"}</span>
                    </button>
                  ))}
                </div>

                <div className="card" style={{marginBottom:14}}>
                  <div className="row" style={{marginBottom:10}}>
                    <button className="btn" style={{fontSize:11,padding:"8px 12px"}} onClick={detectCourse}
                      disabled={gpsStatus==="locating"||gpsStatus==="searching"}>
                      {gpsStatus==="locating"?"📍 Locating…":gpsStatus==="searching"?"🔍 Searching…":"📍 Detect Course"}
                    </button>
                    {gpsStatus==="found"&&detectedCourse&&<span style={{fontSize:12,color:C.green,fontWeight:700}}>✓ {detectedCourse.club_name||detectedCourse.course_name}</span>}
                    {gpsStatus==="error"&&<span style={{fontSize:12,color:C.red,fontWeight:700}}>Not found. Enter manually.</span>}
                  </div>
                  {courseOptions.length>1&&(
                    <div>
                      <div className="lbl" style={{marginBottom:6}}>Multiple courses nearby — pick one:</div>
                      {courseOptions.map((c,i)=>(
                        <button key={i} className="btn-ghost" style={{display:"block",width:"100%",textAlign:"left",marginBottom:5,fontSize:12}} onClick={()=>applyDetectedCourse(c)}>
                          {c.club_name||c.course_name}{c.distance_miles?` · ${c.distance_miles.toFixed(1)} mi`:""}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="row" style={{marginBottom:12}}>
                  <div className="field" style={{flex:1}}>
                    <label className="lbl">Course Name</label>
                    <input className="inp" placeholder="Charter Oak CC" value={current.course} onChange={e=>setCurrent(r=>({...r,course:e.target.value}))}/>
                  </div>
                </div>
                <div className="row" style={{marginBottom:12}}>
                  <div className="field">
                    <label className="lbl">Date</label>
                    <input type="date" className="inp" value={current.date} onChange={e=>setCurrent(r=>({...r,date:e.target.value}))}/>
                  </div>
                  <div className="field">
                    <label className="lbl">Tees</label>
                    <select className="inp" style={{width:80}} value={current.tees} onChange={e=>setCurrent(r=>({...r,tees:e.target.value}))}>
                      {["—","Black","Blue","White","Gold","Red"].map(t=><option key={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="field">
                    <label className="lbl">Weather</label>
                    <select className="inp" style={{width:120}} value={current.weather} onChange={e=>setCurrent(r=>({...r,weather:e.target.value}))}>
                      {["—","Sunny","Partly Cloudy","Overcast","Windy","Light Rain","Hot","Cold"].map(w=><option key={w}>{w}</option>)}
                    </select>
                  </div>
                </div>
                <button className="btn" style={{width:"100%",padding:13,fontSize:14}} disabled={!current.course}
                  onClick={()=>setCurrent(r=>({...r,setup:false}))}>
                  Start Round →
                </button>
              </div>
            ) : (
              // ── HOLE ENTRY ──
              <>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                  <div>
                    <div style={{fontWeight:900,fontSize:15}}>{current.course}</div>
                    <div style={{fontSize:10,color:C.muted,fontWeight:700}}>{current.date}{current.tees?` · ${current.tees}`:""} · {current.holeCount} holes</div>
                  </div>
                  <button className="btn-ghost btn-sm" onClick={()=>setCurrent(r=>({...r,setup:true}))}>Edit</button>
                </div>

                {/* Live summary */}
                {(()=>{const s=calcStats(current.holes);return s.played>0?(<div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
                  {[[toPar(s.toPar),"Score",toParCls(s.toPar)],[pct(s.firHit,s.firTotal),"FIR",""],[pct(s.girHit,s.girTotal),"GIR",""],[s.totalPutts||"—","Putts",""]].map(([v,l,cl])=>(
                    <div key={l} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,padding:"6px 10px"}}>
                      <div style={{fontSize:13,fontWeight:900,color:C.accent}} className={cl}>{v}</div>
                      <div style={{fontSize:8,letterSpacing:"1.5px",textTransform:"uppercase",color:C.muted,fontWeight:900}}>{l}</div>
                    </div>
                  ))}
                </div>):null;})()}

                <div className="divider"/>

                {/* Hole dots */}
                <div className="dots">
                  {current.holes.map((h,i)=>(
                    <div key={i} className={`dot${i===currentHole?" active":h.score!==""?" done":""}`} onClick={()=>setCurrentHole(i)}>{i+1}</div>
                  ))}
                </div>

                {/* Hole card */}
                {(()=>{
                  const hole=current.holes[currentHole];
                  const isP3=hole.par===3;
                  const {label}=scoreInfo(hole.score,hole.par);
                  return (
                    <div className="card">
                      {/* Par + hole num */}
                      <div className="row" style={{marginBottom:12,alignItems:"center"}}>
                        <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:26,fontWeight:900,color:C.accent,width:34}}>{currentHole+1}</div>
                        <div className="field">
                          <label className="lbl">Par</label>
                          <select className="inp" style={{width:62}} value={hole.par} onChange={e=>setHole(currentHole,"par",Number(e.target.value))}>
                            {[3,4,5].map(p=><option key={p}>{p}</option>)}
                          </select>
                        </div>
                        {label&&<div style={{fontSize:12,fontWeight:900,color:C.accent,alignSelf:"flex-end",paddingBottom:8}}>{label}</div>}
                      </div>

                      {/* Score picker */}
                      <label className="lbl">Score</label>
                      <div className="score-picker">
                        {[1,2,3,4,5,6,7,8,9,10].map(n=>{
                          const {label:l,cls}=scoreInfo(n,hole.par);
                          const isSel=String(hole.score)===String(n);
                          return(
                            <button key={n} className={`score-btn${isSel&&cls?" "+cls:""}`} onClick={()=>setHole(currentHole,"score",String(n))}>
                              {n}{isSel&&l?<span className="slbl">{l}</span>:null}
                            </button>
                          );
                        })}
                      </div>

                      {/* Putts picker */}
                      <label className="lbl">Putts</label>
                      <div className="putts-picker">
                        {[0,1,2,3,4,5].map(n=>(
                          <button key={n} className={`putt-btn${String(hole.putts)===String(n)?" sel":""}`} onClick={()=>setHole(currentHole,"putts",String(n))}>{n}</button>
                        ))}
                      </div>

                      <div className="divider"/>

                      {/* FIR / GIR / U&D toggles */}
                      <div style={{display:"flex",gap:14,flexWrap:"wrap",marginBottom:12}}>
                        {!isP3&&(
                          <div className="tog-section">
                            <label className="lbl">Fairway</label>
                            <div className="tog-group">
                              <button className={`tog${hole.fir===true?" hit":""}`} onClick={()=>toggleHole(currentHole,"fir",true)}>✓ Hit</button>
                              <button className={`tog${hole.fir===false?" miss":""}`} onClick={()=>toggleHole(currentHole,"fir",false)}>✕ Miss</button>
                            </div>
                          </div>
                        )}
                        <div className="tog-section">
                          <label className="lbl">Green in Reg</label>
                          <div className="tog-group">
                            <button className={`tog${hole.gir===true?" hit":""}`} onClick={()=>toggleHole(currentHole,"gir",true)}>✓ Hit</button>
                            <button className={`tog${hole.gir===false?" miss":""}`} onClick={()=>toggleHole(currentHole,"gir",false)}>✕ Miss</button>
                          </div>
                        </div>
                        {hole.gir===false&&(
                          <div className="tog-section">
                            <label className="lbl">Up & Down</label>
                            <div className="tog-group">
                              <button className={`tog${hole.upDown===true?" hit":""}`} onClick={()=>toggleHole(currentHole,"upDown",true)}>✓ Made</button>
                              <button className={`tog${hole.upDown===false?" miss":""}`} onClick={()=>toggleHole(currentHole,"upDown",false)}>✕ Missed</button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Sand toggle */}
                      <div className="tog-section" style={{marginBottom:12}}>
                        <label className="lbl">Sand</label>
                        <div className="tog-group">
                          <button className={`tog${hole.inSand?" warn":""}`} onClick={()=>setHole(currentHole,"inSand",!hole.inSand)}>{hole.inSand?"✓ In Sand":"In Sand?"}</button>
                          {hole.inSand&&<>
                            <button className={`tog${hole.sandSave===true?" hit":""}`} onClick={()=>toggleHole(currentHole,"sandSave",true)}>✓ Saved</button>
                            <button className={`tog${hole.sandSave===false?" miss":""}`} onClick={()=>toggleHole(currentHole,"sandSave",false)}>✕ No Save</button>
                          </>}
                        </div>
                      </div>

                      {/* Drive miss grid */}
                      {!isP3&&(
                        <div style={{marginBottom:12}}>
                          <label className="lbl">Drive Miss</label>
                          <div className="miss-grid">
                            <div/><button className={`miss-btn${hole.driveMiss==="Short"?" sel":""}`} onClick={()=>toggleHole(currentHole,"driveMiss","Short")}>Short</button><div/>
                            <button className={`miss-btn${hole.driveMiss==="Left"?" sel":""}`} onClick={()=>toggleHole(currentHole,"driveMiss","Left")}>Left</button>
                            <button className={`miss-btn${hole.driveMiss==="Center"?" sel":""}`} onClick={()=>toggleHole(currentHole,"driveMiss","Center")}>Fair</button>
                            <button className={`miss-btn${hole.driveMiss==="Right"?" sel":""}`} onClick={()=>toggleHole(currentHole,"driveMiss","Right")}>Right</button>
                            <div/><button className={`miss-btn${hole.driveMiss==="Long"?" sel":""}`} onClick={()=>toggleHole(currentHole,"driveMiss","Long")}>Long</button><div/>
                          </div>
                        </div>
                      )}

                      {/* Approach miss grid */}
                      <div style={{marginBottom:12}}>
                        <label className="lbl">Approach Miss</label>
                        <div className="miss-grid">
                          <div/><button className={`miss-btn${hole.approachMiss==="Short"?" sel":""}`} onClick={()=>toggleHole(currentHole,"approachMiss","Short")}>Short</button><div/>
                          <button className={`miss-btn${hole.approachMiss==="Left"?" sel":""}`} onClick={()=>toggleHole(currentHole,"approachMiss","Left")}>Left</button>
                          <button className={`miss-btn${hole.approachMiss==="Center"?" sel":""}`} onClick={()=>toggleHole(currentHole,"approachMiss","Center")}>GIR</button>
                          <button className={`miss-btn${hole.approachMiss==="Right"?" sel":""}`} onClick={()=>toggleHole(currentHole,"approachMiss","Right")}>Right</button>
                          <div/><button className={`miss-btn${hole.approachMiss==="Long"?" sel":""}`} onClick={()=>toggleHole(currentHole,"approachMiss","Long")}>Long</button><div/>
                        </div>
                      </div>

                      {/* Approach dist + club */}
                      <div className="row">
                        <div className="field">
                          <label className="lbl">Approach Dist</label>
                          <input type="number" className="inp" style={{width:80}} placeholder="yds" value={hole.approachDist} onChange={e=>setHole(currentHole,"approachDist",e.target.value)}/>
                        </div>
                        <div className="field">
                          <label className="lbl">Club</label>
                          <select className="inp" style={{width:90}} value={hole.approachClub} onChange={e=>setHole(currentHole,"approachClub",e.target.value)}>
                            <option value="">—</option>
                            {CLUBS.map(c=><option key={c}>{c}</option>)}
                          </select>
                        </div>
                        <div className="field">
                          <label className="lbl">Penalties</label>
                          <input type="number" min={0} max={5} className="inp" style={{width:56}} value={hole.penalties} onChange={e=>setHole(currentHole,"penalties",Number(e.target.value))}/>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Prev / Next */}
                <div className="nav-hole">
                  <button className="btn-ghost" disabled={currentHole===0} onClick={()=>setCurrentHole(h=>h-1)}>← Prev</button>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:13,color:C.muted,fontWeight:900}}>Hole {currentHole+1} of {current.holeCount}</div>
                  <button className="btn" disabled={currentHole===current.holeCount-1} onClick={()=>setCurrentHole(h=>h+1)}>Next →</button>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── ROUNDS ── */}
        {tab==="rounds"&&(
          <div className="sec">
            {viewRound?(
              <RoundDetail round={viewRound} onBack={()=>setViewRound(null)} onDelete={async id=>{await deleteRoundById(id);setViewRound(null);}}/>
            ):rounds.length===0?(
              <div className="empty-state"><div style={{fontSize:48}}>🏌️</div><h3>No rounds yet</h3><p style={{fontSize:13}}>Start a round in the Scorecard tab.</p></div>
            ):(
              <div>
                <div className="section-title">Rounds</div>
                {rounds.map(r=>{
                  const s=calcStats(r.holes);
                  return(
                    <div key={r.id} className="round-item" onClick={()=>setViewRound(r)}>
                      <div>
                        <div style={{fontWeight:900,fontSize:15}}>{r.course||"Unnamed"}</div>
                        <div style={{fontSize:11,color:C.muted,fontWeight:700}}>{r.date}{r.tees?` · ${r.tees}`:""}{r.holeCount?` · ${r.holeCount}H`:""}</div>
                        <div style={{marginTop:5,display:"flex",gap:5,flexWrap:"wrap"}}>
                          <span className="chip chip-g">FIR {pct(s.firHit,s.firTotal)}</span>
                          <span className="chip chip-g">GIR {pct(s.girHit,s.girTotal)}</span>
                          <span className="chip chip-a">{s.totalPutts} putts</span>
                          {s.sandTotal>0&&<span className="chip chip-b">Sand {pct(s.sandMade,s.sandTotal)}</span>}
                        </div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900}} className={toParCls(s.toPar)}>{toPar(s.toPar)}</div>
                        <div style={{fontSize:11,color:C.muted,fontWeight:700}}>{s.totalScore} · {s.played}H</div>
                        <div style={{fontSize:11,color:C.muted,fontWeight:700}}>SG {s.sg}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── STATS ── */}
        {tab==="stats"&&(
          <div className="sec">
            {rounds.length===0?(
              <div className="empty-state"><div style={{fontSize:48}}>📊</div><h3>No data yet</h3></div>
            ):(
              <>
                <div className="section-title">Career Averages <span style={{fontFamily:"inherit",fontSize:12,color:C.muted,fontWeight:700}}>({rounds.length} rounds)</span></div>
                <div className="stat-grid">
                  {[
                    [avgScore!==null?(Number(avgScore)>0?`+${avgScore}`:avgScore==="0.0"?"E":avgScore):"—","Avg Score",null],
                    [pct(aggFirH,aggFirT),"FIR %",aggFirT?aggFirH/aggFirT:0],
                    [pct(aggGirH,aggGirT),"GIR %",aggGirT?aggGirH/aggGirT:0],
                    [avgPuttsR||"—","Putts/Round",null],
                    [pct(aggUdH,aggUdT),"Up & Down",aggUdT?aggUdH/aggUdT:0],
                    [pct(aggSandH,aggSandT),"Sand Save",aggSandT?aggSandH/aggSandT:0],
                    [avgApproachAll?`${avgApproachAll}y`:"—","Avg Approach",null],
                    [sgAvg||"—","Strokes Gained",null],
                  ].map(([v,l,b])=>(
                    <div key={l} className="stat-tile">
                      <div className="stat-val">{v}</div>
                      <div className="stat-lbl">{l}</div>
                      {b!==null&&<div className="bar-wrap"><div className="bar-fill" style={{width:`${Math.round(b*100)}%`}}/></div>}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* ── CLUBS ── */}
        {tab==="clubs"&&(
          <div className="sec">
            <div className="section-title">Club Distances</div>
            {clubDists.length===0?(
              <div className="empty-state"><h3>No club data yet</h3><p style={{fontSize:13}}>Log approach clubs in your rounds.</p></div>
            ):(
              <div className="card">
                {clubDists.map(({club,avg,count})=>{
                  const max=clubDists[0].avg;
                  return(
                    <div key={club} className="club-row">
                      <div className="club-name">{club}</div>
                      <div className="club-dist">{avg}y</div>
                      <div style={{flex:1,background:C.border,borderRadius:3,height:4,overflow:"hidden"}}>
                        <div style={{height:"100%",background:C.accent,width:`${Math.round(avg/max*100)}%`}}/>
                      </div>
                      <div style={{fontSize:10,color:C.muted,fontWeight:700,width:45,textAlign:"right"}}>{count} shot{count!==1?"s":""}</div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── MISSES ── */}
        {tab==="misses"&&(
          <div className="sec">
            <div className="section-title">Miss Breakdown</div>
            {rounds.length===0?(
              <div className="empty-state"><h3>No miss data yet</h3></div>
            ):(
              <div style={{display:"flex",gap:20,flexWrap:"wrap"}}>
                {[["Off the Tee",missMap.drive],["Approach",missMap.approach]].map(([title,data])=>{
                  const max=Math.max(...Object.values(data),1);
                  const cells=[["","Short",""],["Left","Center","Right"],["","Long",""]];
                  return(
                    <div key={title}>
                      <div style={{fontSize:11,color:C.muted,fontWeight:900,letterSpacing:1,textTransform:"uppercase",marginBottom:8}}>{title}</div>
                      <div style={{display:"grid",gridTemplateColumns:"repeat(3,70px)",gap:5}}>
                        {cells.flat().map((label,i)=>{
                          if(!label) return <div key={i}/>;
                          const val=data[label]||0;
                          const hot=val===max&&max>0;
                          return(
                            <div key={label} className={`miss-cell${hot?" hot":""}`}>
                              <div className="miss-cell-val">{val}</div>
                              <div className="miss-cell-lbl">{label}</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── TRENDS ── */}
        {tab==="trends"&&(
          <div className="sec">
            <div className="section-title">Performance Trends</div>
            {trendData.length<2?(
              <div className="empty-state"><h3>Need more rounds</h3><p style={{fontSize:13}}>Save at least 2 rounds to see trends.</p></div>
            ):(
              <>
                {[["Score to Par","score",C.accent],["Total Putts","putts",C.chart3||"#6b8fe0"],["GIR %","gir",C.green],["FIR %","fir",C.accentDim]].map(([title,key,color])=>(
                  <div key={title} className="trend-card">
                    <div className="trend-title">{title}</div>
                    <ResponsiveContainer width="100%" height={130}>
                      <LineChart data={trendData}>
                        <CartesianGrid stroke={C.border} strokeDasharray="3 3"/>
                        <XAxis dataKey="name" stroke={C.muted} tick={{fontSize:10,fontWeight:700}}/>
                        <YAxis stroke={C.muted} tick={{fontSize:10,fontWeight:700}}/>
                        <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:6,fontSize:11,fontWeight:700}}/>
                        <Line type="monotone" dataKey={key} stroke={color} strokeWidth={2.5} dot={{fill:color,r:3.5}}/>
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* ── AI COACH ── */}
        {tab==="coach"&&(
          <div className="sec">
            <div className="section-title">AI Coach</div>
            {rounds.length===0?(
              <div className="empty-state"><div style={{fontSize:48}}>🤖</div><h3>No data to analyze</h3><p style={{fontSize:13}}>Save some rounds first.</p></div>
            ):(
              <>
                <div className="card" style={{marginBottom:16}}>
                  <div style={{fontSize:13,fontWeight:700,lineHeight:1.6,marginBottom:12}}>AI Coach analyzes your {rounds.length} round{rounds.length!==1?"s":""} and gives personalized improvement tips.</div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
                    <span className="chip chip-a">FIR {pct(aggFirH,aggFirT)}</span>
                    <span className="chip chip-g">GIR {pct(aggGirH,aggGirT)}</span>
                    <span className="chip chip-b">{avgPuttsR||"—"} putts/round</span>
                  </div>
                  <button className="btn" onClick={fetchCoach} disabled={coachLoading}>
                    {coachLoading?"Analyzing your game…":coachData?"Refresh Analysis":"Get Coaching Tips"}
                  </button>
                </div>
                {coachError&&<div style={{color:C.red,fontSize:13,fontWeight:700,marginBottom:12}}>{coachError}</div>}
                {coachData?.tips?.map((tip,i)=>(
                  <div key={i} className="coach-tip">
                    <div className="tip-area">{tip.priority==="high"?"🔴":tip.priority==="medium"?"🟡":"🟢"} {tip.area}</div>
                    <div style={{fontSize:13,fontWeight:700,lineHeight:1.5}}>{tip.insight}</div>
                    <div className="tip-drill">🏋️ Drill: {tip.drill}</div>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {/* ── REPORT ── */}
        {tab==="report"&&(
          <div className="sec">
            <div className="section-title">Reports</div>
            <div className="card" style={{marginBottom:14}}>
              <div style={{fontWeight:900,fontSize:15,marginBottom:4}}>Career Report</div>
              <div style={{fontSize:12,fontWeight:700,color:C.muted,marginBottom:14}}>All {rounds.length} rounds — stats, history, club distances.</div>
              <div style={{display:"flex",gap:8}}>
                <button className="btn" disabled={rounds.length===0} onClick={()=>{
                  const html=generateRoundHTML({...rounds[0],course:"Career Report",date:new Date().toISOString().slice(0,10)},calcStats(rounds.flatMap(r=>r.holes)));
                  downloadReport(html,`MyRound_Career_${new Date().toISOString().slice(0,10)}.html`);
                }}>⬇ Download</button>
                <button className="btn-ghost" disabled={rounds.length===0} onClick={async()=>{
                  const html=generateRoundHTML({...rounds[0],course:"Career Report",date:new Date().toISOString().slice(0,10)},calcStats(rounds.flatMap(r=>r.holes)));
                  await shareReport(html,`MyRound_Career_${new Date().toISOString().slice(0,10)}`);
                }}>↗ Share</button>
              </div>
            </div>
            <div className="section-title" style={{fontSize:14}}>Round Reports</div>
            {rounds.length===0?<div className="empty-state" style={{padding:"20px 0"}}><p style={{fontSize:13}}>No rounds saved.</p></div>:
            rounds.map((r,idx)=>{
              const s=calcStats(r.holes);
              return(
                <div key={r.id} className="round-item" style={{cursor:"default"}}>
                  <div>
                    <div style={{fontWeight:900,fontSize:14}}>{r.course||"Unnamed"}</div>
                    <div style={{fontSize:11,color:C.muted,fontWeight:700}}>{r.date}{r.tees?` · ${r.tees}`:""}</div>
                    <div style={{display:"flex",gap:5,marginTop:4}}>
                      <span className="chip chip-g">FIR {pct(s.firHit,s.firTotal)}</span>
                      <span className="chip chip-a">{s.totalPutts} putts</span>
                    </div>
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:6,alignItems:"flex-end"}}>
                    <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:900}} className={toParCls(s.toPar)}>{toPar(s.toPar)}</div>
                    <div style={{display:"flex",gap:6}}>
                      <button className="btn btn-sm" onClick={()=>downloadReport(generateRoundHTML(r,s),`MyRound_${(r.course||"Round").replace(/\s+/g,"_")}_${r.date}.html`)}>⬇</button>
                      <button className="btn-ghost btn-sm" onClick={async()=>await shareReport(generateRoundHTML(r,s),`MyRound_${(r.course||"Round").replace(/\s+/g,"_")}_${r.date}`)}>↗</button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}

function RoundDetail({round,onBack,onDelete}) {
  const s = calcStats(round.holes);
  return(
    <div>
      <div style={{display:"flex",gap:10,marginBottom:14,alignItems:"center"}}>
        <button className="btn-ghost" onClick={onBack}>← Back</button>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:900}}>{round.course}</div>
          <div style={{fontSize:11,color:"#7a8c7f",fontWeight:700}}>{round.date}{round.tees?` · ${round.tees}`:""}{round.holeCount?` · ${round.holeCount}H`:""}</div>
        </div>
        <button className="btn-ghost" style={{color:"#e05252",borderColor:"#e05252"}} onClick={()=>onDelete(round.id)}>Delete</button>
      </div>
      <div className="stat-grid">
        {[
          [toPar(s.toPar),"To Par",`${s.totalScore} strokes`],
          [pct(s.firHit,s.firTotal),"FIR",`${s.firHit}/${s.firTotal}`],
          [pct(s.girHit,s.girTotal),"GIR",`${s.girHit}/${s.girTotal}`],
          [s.totalPutts||"—","Putts",`${s.avgPutts||"—"}/hole`],
          [pct(s.udMade,s.udTotal),"Up & Down",`${s.udMade}/${s.udTotal}`],
          [pct(s.sandMade,s.sandTotal),"Sand Save",`${s.sandMade}/${s.sandTotal}`],
          [s.sg,"Strokes Gained","vs scratch"],
        ].map(([v,l,sub])=>(
          <div key={l} className="stat-tile">
            <div className="stat-val">{v}</div>
            <div className="stat-lbl">{l}</div>
            {sub&&<div className="stat-sub">{sub}</div>}
          </div>
        ))}
      </div>
      <div style={{borderTop:`1px solid #1e3328`,margin:"14px 0"}}/>
      {round.holes.filter(h=>h.score!=="").map((h,i)=>{
        const realIdx=round.holes.indexOf(h);
        const {label,cls}=scoreInfo(h.score,h.par);
        return(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",background:"#132019",borderRadius:8,border:"1px solid #1e3328",marginBottom:5,flexWrap:"wrap"}}>
            <div style={{fontFamily:"'Playfair Display',serif",fontWeight:900,color:"#c8a84b",width:24}}>{realIdx+1}</div>
            <div style={{fontSize:11,color:"#7a8c7f",fontWeight:700}}>P{h.par}</div>
            <div className={`score-btn${cls?" "+cls:""}`} style={{width:30,height:30,fontSize:14,pointerEvents:"none"}}>{h.score}</div>
            {label&&<span className={`chip${h.score&&Number(h.score)-h.par<0?" chip-g":Number(h.score)-h.par===0?" chip-a":" chip-r"}`} style={Number(h.score)-h.par>0?{background:"#3d1414",color:"#ffa8a8"}:{}}>{label}</span>}
            <div style={{fontSize:10,color:"#7a8c7f",marginLeft:"auto",display:"flex",gap:7,flexWrap:"wrap",fontWeight:700}}>
              {h.fir!==null&&<span>FIR:{h.fir?"✓":"✕"}</span>}
              {h.gir!==null&&<span>GIR:{h.gir?"✓":"✕"}</span>}
              {h.putts!==""&&<span>{h.putts}p</span>}
              {h.inSand&&h.sandSave!==null&&<span>Sand:{h.sandSave?"✓":"✕"}</span>}
              {h.approachDist>0&&<span>{h.approachDist}y</span>}
              {h.approachClub&&<span>{h.approachClub}</span>}
              {h.driveMiss&&<span style={{color:"#c8a84b"}}>D:{h.driveMiss}</span>}
              {h.approachMiss&&<span style={{color:"#c8a84b"}}>A:{h.approachMiss}</span>}
              {h.penalties>0&&<span style={{color:"#e05252"}}>{h.penalties}pen</span>}
            </div>
            {h.notes&&<div style={{width:"100%",fontSize:11,color:"#7a8c7f",fontStyle:"italic",paddingLeft:32,fontWeight:700}}>{h.notes}</div>}
          </div>
        );
      })}
    </div>
  );
}
