import React from 'react'
import ReactDOM from 'react-dom/client'
import GolfTracker from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GolfTracker />
  </React.StrictMode>
)
