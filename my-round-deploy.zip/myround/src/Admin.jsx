import { useState, useEffect } from "react"
import { supabase } from "./supabase"

const C = {
  bg: "#0d1a12", card: "#132019", card2: "#0f1c15", border: "#1e3328",
  accent: "#c8a84b", green: "#3dba6c", red: "#e05252", text: "#e8ead4", muted: "#7a8c7f",
  hit: "#1e4230", miss: "#3d1414",
}

function pct(n, d) { if (!d) return "—"; return Math.round(n / d * 100) + "%" }
function toPar(n) { if (n === null || n === undefined) return "—"; if (n === 0) return "E"; return n > 0 ? `+${n}` : `${n}` }
function toParColor(n) { if (!n) return C.muted; return n > 0 ? C.red : C.green }

const css = `
  .admin { font-family: 'DM Sans', sans-serif; color: ${C.text}; background: ${C.bg}; min-height: 100vh; max-width: 960px; margin: 0 auto; padding-bottom: 40px; }
  .admin-header { padding: 20px; border-bottom: 1px solid ${C.border}; display: flex; align-items: center; justify-content: space-between; }
  .admin-title { font-family: 'Playfair Display', serif; font-size: 22px; font-weight: 700; }
  .admin-title span { color: ${C.accent}; }
  .admin-badge { background: ${C.accent}; color: #0d1a12; font-size: 10px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; padding: 3px 8px; border-radius: 20px; margin-left: 10px; }
  .admin-sec { padding: 20px; }
  .admin-stat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; margin-bottom: 24px; }
  .admin-stat { background: ${C.card}; border: 1px solid ${C.border}; border-radius: 10px; padding: 13px 15px; }
  .admin-stat-val { font-family: 'Playfair Display', serif; font-size: 26px; font-weight: 700; color: ${C.accent}; }
  .admin-stat-lbl { font-size: 9px; letter-spacing: 2px; text-transform: uppercase; color: ${C.muted}; margin-top: 2px; }
  .member-list { display: flex; flex-direction: column; gap: 8px; }
  .member-row { background: ${C.card}; border: 1px solid ${C.border}; border-radius: 10px; padding: 13px 15px; display: flex; align-items: center; gap: 12px; cursor: pointer; transition: border-color .2s, background .2s; }
  .member-row:hover { border-color: ${C.accent}; background: #172820; }
  .member-avatar { width: 38px; height: 38px; border-radius: 50%; background: ${C.hit}; border: 1px solid ${C.border}; display: flex; align-items: center; justify-content: center; font-family: 'Playfair Display', serif; font-size: 14px; font-weight: 700; color: ${C.accent}; flex-shrink: 0; }
  .member-name { font-weight: 600; font-size: 14px; }
  .member-meta { font-size: 11px; color: ${C.muted}; margin-top: 2px; }
  .member-chips { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 4px; }
  .chip { display: inline-block; padding: 2px 7px; border-radius: 20px; font-size: 9px; font-weight: 600; letter-spacing: .8px; text-transform: uppercase; }
  .chip-g { background: ${C.hit}; color: #a8ffc4; }
  .chip-a { background: #2a2010; color: ${C.accent}; }
  .chip-b { background: #1a2035; color: #a0b4ff; }
  .score-num { font-family: 'Playfair Display', serif; font-size: 22px; font-weight: 700; margin-left: auto; white-space: nowrap; }
  .search-bar { width: 100%; background: ${C.card}; border: 1px solid ${C.border}; border-radius: 8px; color: ${C.text}; font-family: 'DM Sans', sans-serif; font-size: 14px; padding: 10px 14px; outline: none; box-sizing: border-box; margin-bottom: 14px; }
  .search-bar:focus { border-color: ${C.accent}; }
  .back-btn { background: none; color: ${C.muted}; border: 1px solid ${C.border}; border-radius: 7px; padding: 7px 13px; font-family: 'DM Sans', sans-serif; font-size: 12px; cursor: pointer; }
  .back-btn:hover { color: ${C.text}; }
  .section-title { font-family: 'Playfair Display', serif; font-size: 16px; font-weight: 700; margin-bottom: 12px; }
  .round-item { background: ${C.card2}; border: 1px solid ${C.border}; border-radius: 8px; padding: 10px 13px; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center; gap: 10px; }
  .sort-row { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; }
  .sort-btn { padding: 5px 12px; font-size: 11px; font-weight: 600; border-radius: 20px; border: 1px solid ${C.border}; cursor: pointer; background: none; color: ${C.muted}; font-family: 'DM Sans', sans-serif; transition: all .15s; }
  .sort-btn.active { background: ${C.accent}; color: #0d1a12; border-color: ${C.accent}; }
  .empty { text-align: center; padding: 40px 20px; color: ${C.muted}; font-size: 13px; }
  .signout-btn { background: none; color: ${C.muted}; border: 1px solid ${C.border}; border-radius: 7px; padding: 7px 13px; font-family: 'DM Sans', sans-serif; font-size: 12px; cursor: pointer; }
`

function calcRoundStats(holes) {
  const played = holes.filter(h => h.score !== "")
  const notPar3 = played.filter(h => h.par !== 3)
  const firHit = notPar3.filter(h => h.fir === true).length
  const girHit = played.filter(h => h.gir === true).length
  const putts = played.reduce((a, h) => a + (Number(h.putts) || 0), 0)
  const totalScore = played.reduce((a, h) => a + (Number(h.score) || 0), 0)
  const totalPar = played.reduce((a, h) => a + h.par, 0)
  return { played: played.length, toPar: totalScore - totalPar, totalScore, firHit, firTotal: notPar3.length, girHit, girTotal: played.length, putts }
}

export default function AdminDashboard({ adminUser, onSignOut }) {
  const [members, setMembers] = useState([])
  const [rounds, setRounds] = useState({}) // { userId: [...rounds] }
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [search, setSearch] = useState("")
  const [sort, setSort] = useState("name") // name | rounds | score | recent

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    setLoading(true)
    // Load all profiles
    const { data: profiles } = await supabase.from("profiles").select("*").order("last_name")
    // Load all rounds
    const { data: allRounds } = await supabase.from("rounds").select("*").order("date", { ascending: false })

    // Group rounds by user
    const roundsByUser = {}
    allRounds?.forEach(r => {
      if (!roundsByUser[r.user_id]) roundsByUser[r.user_id] = []
      roundsByUser[r.user_id].push({ ...r, holes: r.holes || [] })
    })

    setMembers(profiles || [])
    setRounds(roundsByUser)
    setLoading(false)
  }

  const getMemberStats = (userId) => {
    const memberRounds = rounds[userId] || []
    if (!memberRounds.length) return null
    const stats = memberRounds.map(r => calcRoundStats(r.holes))
    const full = stats.filter(s => s.played >= 9)
    const avgScore = full.length ? (full.reduce((a, s) => a + s.toPar, 0) / full.length).toFixed(1) : null
    const firH = stats.reduce((a, s) => a + s.firHit, 0)
    const firT = stats.reduce((a, s) => a + s.firTotal, 0)
    const girH = stats.reduce((a, s) => a + s.girHit, 0)
    const girT = stats.reduce((a, s) => a + s.girTotal, 0)
    const avgPutts = full.length ? (full.reduce((a, s) => a + s.putts, 0) / full.length).toFixed(1) : null
    const lastRound = memberRounds[0]
    const lastStats = lastRound ? calcRoundStats(lastRound.holes) : null
    return { avgScore, firPct: pct(firH, firT), girPct: pct(girH, girT), avgPutts, roundCount: memberRounds.length, lastRound, lastStats }
  }

  const filtered = members
    .filter(m => {
      const name = `${m.first_name} ${m.last_name}`.toLowerCase()
      return name.includes(search.toLowerCase()) || m.email?.toLowerCase().includes(search.toLowerCase())
    })
    .sort((a, b) => {
      if (sort === "name") return `${a.last_name}${a.first_name}`.localeCompare(`${b.last_name}${b.first_name}`)
      if (sort === "rounds") return (rounds[b.id]?.length || 0) - (rounds[a.id]?.length || 0)
      if (sort === "score") {
        const sa = getMemberStats(a.id)?.avgScore
        const sb = getMemberStats(b.id)?.avgScore
        if (!sa) return 1; if (!sb) return -1
        return Number(sa) - Number(sb)
      }
      if (sort === "recent") {
        const ra = rounds[a.id]?.[0]?.date || ""
        const rb = rounds[b.id]?.[0]?.date || ""
        return rb.localeCompare(ra)
      }
      return 0
    })

  // Overall club stats
  const allRoundsList = Object.values(rounds).flat()
  const allStats = allRoundsList.map(r => calcRoundStats(r.holes)).filter(s => s.played >= 9)
  const clubAvgScore = allStats.length ? (allStats.reduce((a, s) => a + s.toPar, 0) / allStats.length).toFixed(1) : null
  const totalFirH = allStats.reduce((a, s) => a + s.firHit, 0)
  const totalFirT = allStats.reduce((a, s) => a + s.firTotal, 0)
  const totalGirH = allStats.reduce((a, s) => a + s.girHit, 0)
  const totalGirT = allStats.reduce((a, s) => a + s.girTotal, 0)

  if (selected) {
    const memberRounds = (rounds[selected.id] || [])
    const ms = getMemberStats(selected.id)
    return (
      <>
        <style>{css}</style>
        <div className="admin">
          <div className="admin-header">
            <div>
              <button className="back-btn" onClick={() => setSelected(null)}>← All Members</button>
              <div className="admin-title" style={{ marginTop: 8 }}>
                {selected.first_name} {selected.last_name}
                {selected.handicap && <span style={{ fontSize: 13, color: C.muted, fontFamily: "'DM Sans',sans-serif", fontWeight: 400, marginLeft: 10 }}>HCP {selected.handicap}</span>}
              </div>
              <div style={{ fontSize: 11, color: C.muted }}>{selected.email}</div>
            </div>
          </div>
          <div className="admin-sec">
            {ms ? (
              <>
                <div className="admin-stat-grid">
                  <div className="admin-stat"><div className="admin-stat-val" style={{ color: toParColor(Number(ms.avgScore)) }}>{ms.avgScore !== null ? (Number(ms.avgScore) > 0 ? `+${ms.avgScore}` : ms.avgScore) : "—"}</div><div className="admin-stat-lbl">Avg Score</div></div>
                  <div className="admin-stat"><div className="admin-stat-val">{ms.firPct}</div><div className="admin-stat-lbl">FIR %</div></div>
                  <div className="admin-stat"><div className="admin-stat-val">{ms.girPct}</div><div className="admin-stat-lbl">GIR %</div></div>
                  <div className="admin-stat"><div className="admin-stat-val">{ms.avgPutts || "—"}</div><div className="admin-stat-lbl">Avg Putts</div></div>
                  <div className="admin-stat"><div className="admin-stat-val">{ms.roundCount}</div><div className="admin-stat-lbl">Rounds</div></div>
                </div>
                <div className="section-title">Round History</div>
                {memberRounds.map((r, i) => {
                  const s = calcRoundStats(r.holes)
                  return (
                    <div key={i} className="round-item">
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13 }}>{r.course || "Unnamed"}</div>
                        <div style={{ fontSize: 11, color: C.muted }}>{r.date}{r.tees ? ` · ${r.tees}` : ""}</div>
                        <div style={{ display: "flex", gap: 5, marginTop: 4 }}>
                          <span className="chip chip-g">FIR {pct(s.firHit, s.firTotal)}</span>
                          <span className="chip chip-g">GIR {pct(s.girHit, s.girTotal)}</span>
                          <span className="chip chip-a">{s.putts} putts</span>
                        </div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: toParColor(s.toPar) }}>{toPar(s.toPar)}</div>
                        <div style={{ fontSize: 11, color: C.muted }}>{s.totalScore} · {s.played}H</div>
                      </div>
                    </div>
                  )
                })}
              </>
            ) : (
              <div className="empty">No rounds saved yet for this member.</div>
            )}
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <style>{css}</style>
      <div className="admin">
        <div className="admin-header">
          <div>
            <div className="admin-title">My<span> Round</span> <span className="admin-badge">Admin</span></div>
            <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>Charter Oak Country Club</div>
          </div>
          <button className="signout-btn" onClick={onSignOut}>Sign Out</button>
        </div>

        <div className="admin-sec">
          {/* Club overview stats */}
          <div className="admin-stat-grid">
            <div className="admin-stat"><div className="admin-stat-val">{members.length}</div><div className="admin-stat-lbl">Members</div></div>
            <div className="admin-stat"><div className="admin-stat-val">{allRoundsList.length}</div><div className="admin-stat-lbl">Total Rounds</div></div>
            <div className="admin-stat"><div className="admin-stat-val">{clubAvgScore !== null ? (Number(clubAvgScore) > 0 ? `+${clubAvgScore}` : clubAvgScore) : "—"}</div><div className="admin-stat-lbl">Club Avg</div></div>
            <div className="admin-stat"><div className="admin-stat-val">{pct(totalFirH, totalFirT)}</div><div className="admin-stat-lbl">Club FIR</div></div>
            <div className="admin-stat"><div className="admin-stat-val">{pct(totalGirH, totalGirT)}</div><div className="admin-stat-lbl">Club GIR</div></div>
            <div className="admin-stat"><div className="admin-stat-val">{250 - members.length}</div><div className="admin-stat-lbl">Slots Left</div></div>
          </div>

          {/* Search + sort */}
          <input className="search-bar" placeholder="Search members by name or email…" value={search} onChange={e => setSearch(e.target.value)} />
          <div className="sort-row">
            {[["name","Name"],["rounds","Most Rounds"],["score","Best Avg"],["recent","Most Recent"]].map(([id, label]) => (
              <button key={id} className={`sort-btn ${sort === id ? "active" : ""}`} onClick={() => setSort(id)}>{label}</button>
            ))}
          </div>

          {loading ? (
            <div className="empty">Loading members…</div>
          ) : filtered.length === 0 ? (
            <div className="empty">No members found.</div>
          ) : (
            <div className="member-list">
              {filtered.map(m => {
                const ms = getMemberStats(m.id)
                const initials = `${m.first_name?.[0] || ""}${m.last_name?.[0] || ""}`.toUpperCase()
                return (
                  <div key={m.id} className="member-row" onClick={() => setSelected(m)}>
                    <div className="member-avatar">{initials}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="member-name">{m.first_name} {m.last_name}</div>
                      <div className="member-meta">{m.email}{m.handicap ? ` · HCP ${m.handicap}` : ""}</div>
                      {ms && (
                        <div className="member-chips">
                          <span className="chip chip-a">{ms.roundCount} round{ms.roundCount !== 1 ? "s" : ""}</span>
                          <span className="chip chip-g">FIR {ms.firPct}</span>
                          <span className="chip chip-g">GIR {ms.girPct}</span>
                          {ms.lastRound && <span className="chip chip-b">Last: {ms.lastRound.date}</span>}
                        </div>
                      )}
                    </div>
                    {ms?.avgScore !== null && ms?.avgScore !== undefined ? (
                      <div style={{ textAlign: "right", flexShrink: 0 }}>
                        <div className="score-num" style={{ color: toParColor(Number(ms.avgScore)) }}>
                          {Number(ms.avgScore) > 0 ? `+${ms.avgScore}` : ms.avgScore === "0.0" ? "E" : ms.avgScore}
                        </div>
                        <div style={{ fontSize: 10, color: C.muted }}>avg</div>
                      </div>
                    ) : (
                      <div style={{ fontSize: 12, color: C.muted, flexShrink: 0 }}>No rounds</div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
