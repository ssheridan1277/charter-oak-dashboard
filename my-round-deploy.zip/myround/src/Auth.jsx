import { useState } from "react"
import { supabase, MAX_USERS } from "./supabase"

const C = {
  bg: "#0d1a12", card: "#132019", border: "#1e3328",
  accent: "#c8a84b", green: "#3dba6c", red: "#e05252",
  text: "#e8ead4", muted: "#7a8c7f",
}

const css = `
  .auth-wrap { min-height: 100vh; background: ${C.bg}; display: flex; align-items: center; justify-content: center; padding: 20px; font-family: 'DM Sans', sans-serif; }
  .auth-card { background: ${C.card}; border: 1px solid ${C.border}; border-radius: 16px; padding: 36px 32px; width: 100%; max-width: 400px; }
  .auth-logo { font-family: 'Playfair Display', serif; font-size: 28px; font-weight: 700; color: ${C.text}; margin-bottom: 4px; }
  .auth-logo span { color: ${C.accent}; }
  .auth-sub { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: ${C.muted}; margin-bottom: 32px; }
  .auth-title { font-size: 18px; font-weight: 600; color: ${C.text}; margin-bottom: 20px; }
  .auth-field { margin-bottom: 14px; }
  .auth-label { font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase; color: ${C.muted}; margin-bottom: 5px; display: block; }
  .auth-input { width: 100%; background: #0d1a12; border: 1px solid ${C.border}; border-radius: 8px; color: ${C.text}; font-family: 'DM Sans', sans-serif; font-size: 14px; padding: 11px 14px; outline: none; box-sizing: border-box; transition: border-color .2s; }
  .auth-input:focus { border-color: ${C.accent}; }
  .auth-btn { width: 100%; background: ${C.accent}; color: #0d1a12; border: none; border-radius: 8px; padding: 13px; font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 700; cursor: pointer; margin-top: 8px; transition: opacity .2s; }
  .auth-btn:hover { opacity: .85; }
  .auth-btn:disabled { opacity: .4; cursor: not-allowed; }
  .auth-toggle { margin-top: 20px; text-align: center; font-size: 13px; color: ${C.muted}; }
  .auth-toggle button { background: none; border: none; color: ${C.accent}; cursor: pointer; font-size: 13px; font-family: 'DM Sans', sans-serif; text-decoration: underline; }
  .auth-error { background: #3d1414; border: 1px solid ${C.red}; border-radius: 8px; color: #ffa8a8; font-size: 13px; padding: 10px 14px; margin-bottom: 14px; }
  .auth-success { background: #1e4230; border: 1px solid ${C.green}; border-radius: 8px; color: #a8ffc4; font-size: 13px; padding: 10px 14px; margin-bottom: 14px; }
  .auth-divider { border: none; border-top: 1px solid ${C.border}; margin: 20px 0; }
  .auth-name-row { display: flex; gap: 10px; }
  .auth-name-row .auth-field { flex: 1; }
`

export default function Auth({ onAuth }) {
  const [mode, setMode] = useState("login") // login | signup
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [handicap, setHandicap] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)

  const handleLogin = async () => {
    setLoading(true); setError(null)
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false); return }
    onAuth(data.user)
    setLoading(false)
  }

  const handleSignup = async () => {
    if (!firstName || !lastName) { setError("Please enter your full name."); return }
    if (password.length < 6) { setError("Password must be at least 6 characters."); return }
    setLoading(true); setError(null)

    // Check user count
    const { count } = await supabase.from("profiles").select("*", { count: "exact", head: true })
    if (count >= MAX_USERS) {
      setError("This app is currently limited to Charter Oak members. Please contact the pro shop.")
      setLoading(false); return
    }

    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: {
        data: { first_name: firstName, last_name: lastName, handicap: handicap || null }
      }
    })
    if (error) { setError(error.message); setLoading(false); return }
    setSuccess("Account created! Check your email to confirm, then log in.")
    setMode("login")
    setLoading(false)
  }

  const handleForgot = async () => {
    if (!email) { setError("Enter your email first."); return }
    const { error } = await supabase.auth.resetPasswordForEmail(email)
    if (error) { setError(error.message); return }
    setSuccess("Password reset email sent.")
  }

  return (
    <>
      <style>{css}</style>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@400;600;700&display=swap" rel="stylesheet" />
      <div className="auth-wrap">
        <div className="auth-card">
          <div className="auth-logo">My<span> Round</span></div>
          <div className="auth-sub">Golf Performance Log</div>

          <div className="auth-title">{mode === "login" ? "Welcome back" : "Create your account"}</div>

          {error && <div className="auth-error">{error}</div>}
          {success && <div className="auth-success">{success}</div>}

          {mode === "signup" && (
            <div className="auth-name-row">
              <div className="auth-field">
                <label className="auth-label">First Name</label>
                <input className="auth-input" placeholder="Steve" value={firstName} onChange={e => setFirstName(e.target.value)} />
              </div>
              <div className="auth-field">
                <label className="auth-label">Last Name</label>
                <input className="auth-input" placeholder="Smith" value={lastName} onChange={e => setLastName(e.target.value)} />
              </div>
            </div>
          )}

          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input className="auth-input" type="email" placeholder="you@email.com" value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === "Enter" && (mode === "login" ? handleLogin() : handleSignup())} />
          </div>

          <div className="auth-field">
            <label className="auth-label">Password</label>
            <input className="auth-input" type="password" placeholder="••••••••" value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === "Enter" && (mode === "login" ? handleLogin() : handleSignup())} />
          </div>

          {mode === "signup" && (
            <div className="auth-field">
              <label className="auth-label">Handicap Index (optional)</label>
              <input className="auth-input" type="number" placeholder="e.g. 12.4" value={handicap}
                onChange={e => setHandicap(e.target.value)} />
            </div>
          )}

          <button className="auth-btn" disabled={loading || !email || !password}
            onClick={mode === "login" ? handleLogin : handleSignup}>
            {loading ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
          </button>

          {mode === "login" && (
            <div style={{ textAlign: "right", marginTop: 8 }}>
              <button style={{ background: "none", border: "none", color: C.muted, fontSize: 12, cursor: "pointer", fontFamily: "'DM Sans',sans-serif" }}
                onClick={handleForgot}>Forgot password?</button>
            </div>
          )}

          <hr className="auth-divider" />

          <div className="auth-toggle">
            {mode === "login" ? (
              <>Don't have an account? <button onClick={() => { setMode("signup"); setError(null); setSuccess(null) }}>Sign up</button></>
            ) : (
              <>Already have an account? <button onClick={() => { setMode("login"); setError(null); setSuccess(null) }}>Sign in</button></>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
